create view FULLEMAILNEW as
select lower(EMAIL)||'@gmail.com' as fullEmailNew from EMPLOYEES
/


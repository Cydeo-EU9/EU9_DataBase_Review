create view FULLEMAIL as
select FIRST_NAME||'.'||LAST_NAME||'@gmail' as fullEmail from EMPLOYEES
/


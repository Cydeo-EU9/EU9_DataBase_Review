create view EMAILINIT1 as
select EMAIL as email, initcap(EMAIL) as initEmail from EMPLOYEES
/


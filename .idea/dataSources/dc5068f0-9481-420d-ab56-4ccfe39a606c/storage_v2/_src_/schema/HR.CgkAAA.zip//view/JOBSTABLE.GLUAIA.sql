create view JOBSTABLE as
select "JOB_ID","JOB_TITLE","MIN_SALARY","MAX_SALARY" from jobs
/


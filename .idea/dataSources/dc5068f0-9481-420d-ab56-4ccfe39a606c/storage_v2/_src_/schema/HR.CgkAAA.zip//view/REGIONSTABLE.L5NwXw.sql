create view REGIONSTABLE as
select "REGION_ID","REGION_NAME" from REGIONS
/


create view EMAILINIT as
select  EMAIL from EMPLOYEES
/


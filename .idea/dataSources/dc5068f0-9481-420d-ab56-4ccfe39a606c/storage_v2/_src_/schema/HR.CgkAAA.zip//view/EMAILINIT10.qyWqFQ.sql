create view EMAILINIT10 as
select EMAIL, initcap(EMAIL) as initEmail10 from EMPLOYEES
/


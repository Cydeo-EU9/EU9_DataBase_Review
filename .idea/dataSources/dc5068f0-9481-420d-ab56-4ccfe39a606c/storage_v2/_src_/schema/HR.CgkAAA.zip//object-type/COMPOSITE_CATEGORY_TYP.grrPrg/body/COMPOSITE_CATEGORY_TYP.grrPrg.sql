create TYPE BODY COMPOSITE_CATEGORY_TYP 
    AS 
    MEMBER FUNCTION CATEGORY_DESCRIBE 
    RETURN VARCHAR 
    AS 
    BEGIN
      RETURN 'composite_category_typ';
    END;

    END 
;
/

